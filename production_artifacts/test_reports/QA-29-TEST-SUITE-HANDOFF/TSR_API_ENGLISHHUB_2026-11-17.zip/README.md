# TSR API EnglishHub

Open TSR_API.pdf to read or print. Open TSR_API.html to follow evidence links. TSR_API.md is the editable version.

Scope: recovered API suites 8-15, first runs 18 Sep-7 Oct and regression 10 Oct 2026. Separate appendix for historical Docker replay on 17 Nov. Not a whole-product acceptance sign-off.

Evidence is bundled in evidence/. CSV tables and TSR_DATA.json provide structured statistics. VERIFICATION.json records layout, source-count and link checks.
