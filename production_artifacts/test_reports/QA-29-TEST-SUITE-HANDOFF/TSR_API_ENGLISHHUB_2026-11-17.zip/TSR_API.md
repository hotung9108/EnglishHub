# Test Summary Report - EnglishHub API

EH-TSR-API-20261117-01 | v1.0 | Tổng hợp ngày 17/11/2026

[PDF](TSR_API.pdf) | [HTML](TSR_API.html) | [Minh chứng theo suite](evidence/api-suite-history/index.html)

## 1. Thông tin báo cáo

Mã tài liệu: EH-TSR-API-20261117-01 | Phiên bản: 1.0 | Ngày tổng hợp: 17/11/2026 (Asia/Saigon).

Đối tượng: dự án EnglishHub, kiểm thử API theo suite 8-15. Kỳ lịch sử chính: 18/09-10/10/2026; tái hiện Docker ngày 17/11 được trình bày riêng ở phụ lục.

Trạng thái: bản tổng hợp để review; chưa ghi nhận người phê duyệt hoặc quyết định nghiệm thu. Báo cáo được lập hồi cứu, không ghi lùi ngày thành báo cáo đã ban hành cuối sprint.

Căn cứ bố cục: Test Plan Group-04, mục 10.4, trang PDF 29 (số in 27). Báo cáo gồm phạm vi/phiên bản/môi trường, kết quả, lỗi và xử lý, đánh giá chức năng/Usability/Maintainability, giới hạn và mức sẵn sàng.


## 2. Tóm tắt kết quả

Đã thu hồi đủ 8 report gốc từ Trello (6 HTML Newman, 2 PDF Qase). Cả 8 có SHA-256 khớp nguồn ghi trong TSR ngày 08/10; đồng thời thu hồi report hồi quy 10/10 và lập danh mục 83 tệp báo cáo API còn lưu.

Giai đoạn đầu có 524 ca Assessment: 453 PASS, 19 FAIL, 42 BLOCKED, 10 SKIPPED; 31 bước Support được đếm riêng. Tỷ lệ PASS trên toàn bộ Assessment là 86,45% (453/524); trên các ca đã có kết quả PASS/FAIL là 95,97% (453/472).

Đợt hồi quy 10/10 ghi 560 dòng kết quả: 453 PASS, 7 FAIL, 88 BLOCKED, 12 SKIPPED. Có 4 ca cần đổi PASS sang BLOCKED theo ghi chú audit nhưng Qase chưa chỉnh tại thời điểm report. Không cộng hai đợt thành số ca duy nhất và không so tỷ lệ như hai bộ có cùng phạm vi.

19 ca FAIL gốc liên kết 18 issue; thêm #115 liên quan các ca Grading bị chặn. Cả 19 issue liên kết đang CLOSED trong snapshot 17/11; trạng thái đóng không tự chứng minh lỗi đã được sửa ở mọi build.

Kết luận: hồ sơ đủ làm minh chứng cho các đợt API đã tìm được. Chưa đủ căn cứ nghiệm thu toàn sản phẩm hoặc xác nhận chất lượng build staging hiện tại chỉ từ những kết quả lịch sử này.


## 3. Phạm vi và cách tính

Bao gồm: Auth, User, User Profile, Classes, Assignments, Submissions, Student Evaluation và Grading; report gốc, export case, issue, bình luận Trello và retest liên quan.

Không đưa Selenium 170 ca, component/unit tests, tải lớn, chất lượng học thuật của AI hay mọi tiêu chí NFR vào mẫu số API. Những phần này cần TSR/phụ lục bằng chứng tương ứng trước khi nghiệm thu toàn dự án.

Assessment là ca nghiệp vụ trong CSV lịch sử; Support là bước dựng dữ liệu/dọn dữ liệu. Request là lượt gọi HTTP; assertion là phép kiểm tra. Một ca có thể sinh nhiều request và nhiều assertion lỗi.

FAIL trong báo cáo nguồn là kết quả kiểm thử, chưa mặc nhiên là bug sản phẩm. Các nhóm kỳ vọng chưa chốt, fixture/môi trường, chưa tái hiện, lỗi thật và đã sửa phải được đánh giá riêng. Trạng thái issue hiện tại được tách với trạng thái tại ngày chạy.

83 tệp API là danh mục artifact: summary và raw Newman có thể thuộc cùng một run. Không dùng số tệp hoặc ngày sửa tệp để tính số run/ngày thực thi.


## 4. Phiên bản và môi trường

Các commit dưới đây chỉ là HEAD local ứng viên suy từ reflog. Chưa có image digest/build SHA chứng minh chính xác application build của các lần chạy gốc; không dùng commit sửa bug làm commit phát hiện bug.

Auth mang tên run Staging nhưng PDF ghi thực thi localhost:8080. Grading dùng staging; dữ liệu và cấu hình gốc chưa được khôi phục đồng nhất. Expected trong case cũ không được mặc nhiên coi là yêu cầu của SRS final_2 hiện tại.

| Suite | Môi trường theo report | HEAD ứng viên | Build gốc |
| --- | --- | --- | --- |
| 8 | Local localhost:8080 (PDF ghi rõ) | 36e05b47587d | Chưa xác minh |
| 9 | Tên run Staging; host chưa xác minh | cfc8d3f0d27b | Chưa xác minh |
| 10 | Local localhost:8080 trong HTML | c66ebe2f82e4 | Chưa xác minh |
| 11 | Local localhost:8080 trong HTML | c66ebe2f82e4 | Chưa xác minh |
| 12 | Local localhost:8080 trong HTML | 230a50b9be71 | Chưa xác minh |
| 13 | Local localhost:8080 trong HTML | f3e8758e45ec | Chưa xác minh |
| 14 | Local localhost:8080 trong HTML | 0b08836fe892 | Chưa xác minh |
| 15 | Staging api-staging.hotung9108.me | Chưa biết SHA deploy | Chưa xác minh |


## 5. Kết quả giai đoạn 18/09-07/10

Bảng dưới đếm ca Assessment từ export đã thu hồi; không cộng 31 Support. Một số report công cụ và export Qase chỉ được chứng minh liên quan cùng chức năng, chưa xác minh là cùng lần thử.

| Suite | Chức năng | Ngày nguồn | Tổng | PASS | FAIL | BLOCK | SKIP |
| --- | --- | --- | --- | --- | --- | --- | --- |
| 8 | Auth | 2026-09-18 | 34 | 31 | 2 | 0 | 1 |
| 9 | User | 2026-09-21 | 35 | 28 | 3 | 4 | 0 |
| 10 | User Profile | 2026-09-24 | 41 | 41 | 0 | 0 | 0 |
| 11 | Classes | 2026-09-26 | 60 | 49 | 11 | 0 | 0 |
| 12 | Assignments | 2026-09-27 | 76 | 75 | 1 | 0 | 0 |
| 13 | Submissions | 2026-10-03 | 84 | 84 | 0 | 0 | 0 |
| 14 | Student Evaluation | 2026-10-05 | 73 | 71 | 2 | 0 | 0 |
| 15 | Grading | 2026-10-07 | 121 | 74 | 0 | 38 | 9 |
|  | TỔNG |  | 524 | 453 | 19 | 42 | 10 |


## 6. Đối chiếu report công cụ và Qase

User Profile: HTML ghi 0 assertion FAIL, 2 assertion SKIPPED; export/TSR ghi 41 ca PASS. Giữ cả hai, chưa sửa số để ép chúng thành một run.

Classes: HTML gốc có 11 assertion FAIL; export có 11 ca FAIL. Trong đó #71 yêu cầu tên lớp không trùng còn cần xác nhận, không khẳng định có 11 bug hợp lệ.

Assignments: HTML có 1 assertion FAIL tại Qase #1541 (TC_ASSIGNMENT_45). Trường maxSubmissions thiếu trong phản hồi; việc PostgreSQL lưu đúng không bác bỏ lỗi response.

Student Evaluation: HTML có 10 assertion FAIL, export có 2 ca FAIL gắn #102. Nhiều assertion lỗi trên cùng ca và kiểm tra bổ sung nên không quy đổi thành 10 bug.

Grading: HTML có 16 lỗi assertion/fixture; export có 38 BLOCKED, 9 SKIPPED. Không thay 38 BLOCKED bằng 16 FAIL. #115 là vấn đề chấm điểm hợp lệ làm các fixture bị chặn.

Auth: PDF ghi 32 PASS, gồm 1 bước Support; Assessment là 31 PASS. Assignments có 16 Support PASS, Submissions có 6 Support PASS, Classes có 8 Support PASS.


## 7. Kết quả hồi quy ngày 10/10

Nguồn: report-audited.html đính kèm thẻ QA-23 hiện tại (tên trong comment lịch sử QA-19), liên kết Qase run 19. Bảng giữ số đã audit trong report, không tuyên bố đã đồng bộ lại Qase.

Phạm vi đợt này khác giai đoạn đầu: suite 12 có 91 dòng, suite 13 có 104 dòng, suite 14 có 74 dòng. Không áp lại nhãn 524 Assessment cho toàn bộ 560 dòng.

7 dòng FAIL gồm: Auth EAM-285, 289, 294, 295; User EAM-689; Classes EAM-1286; Assignments TC_ASSIGNMENT_45 chỉ có report local và chưa map export tương ứng. Không suy ra 7 nguyên nhân bug độc lập.

| Suite | Tổng dòng | PASS | FAIL | BLOCKED | SKIPPED |
| --- | --- | --- | --- | --- | --- |
| 8 | 34 | 13 | 4 | 17 | 0 |
| 9 | 35 | 33 | 1 | 1 | 0 |
| 10 | 41 | 38 | 0 | 3 | 0 |
| 11 | 60 | 59 | 1 | 0 | 0 |
| 12 | 91 | 90 | 1 | 0 | 0 |
| 13 | 104 | 78 | 0 | 26 | 0 |
| 14 | 74 | 72 | 0 | 2 | 0 |
| 15 | 121 | 70 | 0 | 39 | 12 |
| TỔNG | 560 | 453 | 7 | 88 | 12 |


## 8. Lỗi và tình trạng xử lý

19 issue trong bảng = 18 issue liên kết các ca FAIL gốc + #115 liên kết các ca BLOCKED. CLOSED lấy từ snapshot GitHub ngày 17/11; không thay thế bằng chứng retest hoặc trạng thái lịch sử cuối mỗi đợt.

Kết luận cột cuối dựa trên kiểm tra bổ sung ngày 17/11 trên commit cũ/ứng viên. Lỗi còn tái hiện ở phiên bản cũ không có nghĩa staging hiện tại vẫn lỗi. Severity/priority chưa được chuẩn hóa đủ nguồn để thống kê; không tự gán P0-P4.

| Issue | Triệu chứng / phạm vi | Tracker 17/11 | Xác minh bổ sung |
| --- | --- | --- | --- |
| #20 | Sai Content-Type: trả 500 thay vì 415. | CLOSED | Tái hiện trên commit cũ |
| #21 | Logout với access token hết hạn: kỳ vọng đã bị phản bác. | CLOSED | Kỳ vọng bị phản bác |
| #34 | Cập nhật họ tên trả 500 trong lần ghi nhận cũ. | CLOSED | Chưa tái hiện |
| #37 | Đổi mật khẩu trả 500 trong lần ghi nhận cũ. | CLOSED | Chưa tái hiện |
| #38 | Admin cập nhật user trả 500. | CLOSED | Chưa tái hiện |
| #62 | Giáo viên xóa lớp: trả 409 thay vì 403. | CLOSED | Tái hiện trên commit cũ |
| #63 | Học viên ngoài lớp đọc được danh sách thành viên. | CLOSED | Tái hiện trên commit cũ |
| #64 | Giáo viên thêm được thành viên theo ma trận quyền cũ. | CLOSED | Tái hiện trên commit cũ |
| #65 | Xóa thành viên thuộc lớp khác: từng ghi 200 thay vì 404. | CLOSED | Chưa tái hiện |
| #66 | Giáo viên xóa được thành viên theo ma trận quyền cũ. | CLOSED | Tái hiện trên commit cũ |
| #67 | Học viên ngoài lớp đọc được chi tiết lớp. | CLOSED | Tái hiện trên commit cũ |
| #68 | Tên lớp 151 ký tự từng được tạo thành công. | CLOSED | Chưa tái hiện |
| #69 | Giáo viên tạo được lớp theo kỳ vọng quyền cũ. | CLOSED | Tái hiện trên commit cũ |
| #70 | Học viên tạo được lớp theo kỳ vọng quyền cũ. | CLOSED | Tái hiện trên commit cũ |
| #71 | Tên lớp trùng: quy tắc chưa được xác nhận. | CLOSED | Quy tắc chưa chốt |
| #72 | Giáo viên cập nhật lớp theo kỳ vọng quyền cũ. | CLOSED | Tái hiện trên commit cũ |
| #76 | GET thiếu maxSubmissions; PostgreSQL vẫn lưu đúng. | CLOSED | Tái hiện trên commit cũ |
| #102 | Giáo viên không phụ trách đọc được đánh giá (2 ca). | CLOSED | Tái hiện trên commit cũ |
| #115 | Điểm 6/10 bị từ chối, làm hỏng fixture Grading. | CLOSED | Tái hiện bổ sung; chặn fixture |


## 9. Đánh giá yêu cầu và phần chưa kiểm chứng

Chức năng: có bằng chứng từng suite và từng tình huống được ghi nhận. Auth/User/Classes từng có FAIL; Grading còn thiếu kết quả do fixture/AI và các tiền đề khác. Không tuyên bố mọi UC hoặc mọi đường biên đã được kiểm đầy đủ.

Usability: các suite API không đủ chứng cứ nghiệm thu giao diện, khả năng sử dụng hoặc trải nghiệm người dùng. Tiêu chí USA theo đặc tả cần bằng chứng UI riêng; trạng thái trong TSR API này là CHƯA ĐÁNH GIÁ.

Maintainability: danh mục report, mã băm và khả năng truy vết hỗ trợ quản lý hồ sơ; chưa thay kết quả coverage, review, CI hoặc các tiêu chí MAI. Trạng thái nghiệm thu nhóm MAI trong TSR này là CHƯA ĐÁNH GIÁ.

Chưa kiểm chứng đầy đủ: application build từng run; mọi ca BLOCKED/SKIPPED; fixture AI thật; bất đồng bộ Qase sau audit; toàn bộ điều kiện cleanup lịch sử; độ phủ theo phiên bản SRS đã chốt. Không suy tỷ lệ bao phủ UC từ tỷ lệ PASS.

Ma trận UC lịch sử và final_2 hiện tại khác phiên bản. Giữ nguồn yêu cầu gốc của từng ca; muốn dùng làm nghiệm thu hiện tại phải ánh xạ lại UC và expected trước.


## 10. Giới hạn, sai lệch và dữ liệu test

Đây là tổng hợp hồi cứu. Ngày 17/11 là ngày lập TSR/thu hồi, không phải ngày chạy lại 8 suite gốc. File có sẵn được giữ nguyên và kiểm tra mã băm.

Chưa xác định chính xác SHA/image đã triển khai của các run cũ. Các commit trong bảng là ứng viên, không đủ điều kiện gọi là đã chạy đúng toàn bộ phiên bản lịch sử. Report gốc là minh chứng ưu tiên khi vẫn thu hồi được.

Qase run cũ có thể không truy cập được; chưa xác minh nguyên nhân do xóa, thời hạn hay quyền. Export/PDF/HTML gốc được dùng làm nguồn thay thế có ghi xuất xứ; không tạo run Qase giả hoặc ghi lùi ngày.

Cleanup gốc không có hồ sơ đồng nhất. Collection Submissions nêu có hàng submission/lớp fixture còn lưu vì thiếu purge API; không tuyên bố đã xóa sạch. ARCHIVED cũng không đồng nghĩa DELETED.

Tái hiện Docker dùng PostgreSQL mới và tài khoản giả lập riêng, không phải snapshot DB gốc. Container riêng đã dừng; DB dump/volume còn giữ phục vụ kiểm toán. Không đưa dữ liệu thử nghiệm này vào staging.

Theo TP 10.4, chưa đủ bằng chứng đánh giá đầy đủ chức năng, Usability, Maintainability và quyết định nghiệm thu toàn hệ thống. Tài liệu này chỉ chốt số liệu có căn cứ trong phạm vi API đã nêu.


## 11. Kết luận và việc cần hoàn tất

Hồ sơ API đã có nguồn gốc kiểm tra được: đủ 8 report suite đầu tiên, hồi quy 10/10, liên kết case-issue-retest và chỉ mục các report còn lưu. Có thể dùng để review quá trình kiểm thử và giải trình số liệu.

Chưa đưa ra quyết định nghiệm thu build hiện tại. Cần người phụ trách xác nhận build/SRS mục tiêu, xử lý các BLOCKED/SKIPPED còn phù hợp, đối soát 4 ca audit với Qase và bổ sung kết quả UI/NFR theo TP trước khi nghiệm thu toàn dự án.

Khi cần chạy mới, tạo run mới theo từng suite với commit ứng dụng, collection hash, môi trường, fixture và cleanup; không dùng run mới thay lịch sử đã thu hồi. Lỗi đã có issue dùng lại liên kết; không tạo trùng chỉ vì xuất hiện ở nhiều assertion.

Người review: chưa ghi nhận. Người phê duyệt: chưa ghi nhận. Ngày phê duyệt và quyết định chấp nhận/ngoại lệ: chưa ghi nhận.


## Phụ lục A. Tái hiện Docker ngày 17/11

Đây là đợt kiểm chứng bổ sung độc lập. Đã build 7 image từ commit cũ/ứng viên. Trong 19 ca FAIL cũ: 12 ca tái hiện triệu chứng (11 issue), 5 chưa tái hiện, 1 bị phản bác kỳ vọng (#21), 1 chưa xác nhận quy tắc (#71). Tái hiện thêm #103, #115, #132 ngoài tập 19 FAIL; chưa coi là ba nguyên nhân độc lập.

Assignments: collection cũ trên 230a50b đạt 75 PASS/1 FAIL, bản sửa 5f01d32 đạt 76 PASS/0 FAIL; 16 Support tách riêng. #76 được xác nhận là thiếu trường response, không phải DB không lưu.

Classes: collection trên c66ebe2 đạt 50 PASS/10 FAIL so với gốc 49 PASS/11 FAIL. #65/#68 chưa gặp lại; chuỗi fixture phát sinh FAIL EAM-1314 và làm EAM-1318 trả 404. Các probe fixture riêng được dùng phân loại issue; không gọi cả 10 FAIL collection là 10 bug cũ đã tái hiện.

Auth/User/Evaluation/Grading chủ yếu dùng kịch bản tối thiểu theo issue trong đợt này, không gọi là đã chạy lại đầy đủ toàn suite. Các lần thử sai fixture được giữ riêng, không dùng làm kết luận chính.


## Phụ lục B. Nguồn và đường dẫn minh chứng

Mở TSR_API.html để đọc bản HTML, hoặc evidence/api-suite-history/index.html để tra cứu theo suite/ngày. Tệp summary.json trong từng suite chứa URL report gốc, thẻ Trello, issue, bình luận và hash.

Gói gửi đọc chứa bản trích report đã che thông tin nhạy cảm; bản gốc nguyên trạng lưu riêng trong backup nội bộ tại D:/ki7/prj1-archive/suite-history-recovery-20261117/. Không đính kèm mật khẩu, token hoặc DB dump vào gói gửi đọc.

| Mã | Nguồn | Định vị |
| --- | --- | --- |
| S01 | Test Plan Group-04, mục 10.4; PDF trang 29/số in 27. | Tài liệu người dùng cung cấp; hash trong nguồn tham chiếu. |
| S02 | 8 report suite gốc, tải lại từ Trello; SHA-256 khớp TSR 08/10. | evidence/api-suite-history/original-source-manifest.json |
| S03 | CSV chuẩn hóa 08/10: 555 dòng = 524 Assessment + 31 Support. | evidence/TSR_case_results_2026-10-08.csv |
| S04 | report-audited.html 10/10, thẻ Trello vAkapymL, Qase run 19. | evidence/api-suite-history/suite-history.json |
| S05 | Issue và bình luận retest trong snapshot GitHub 17/11. | evidence/api-suite-history/<suite>/<ngày>/summary.json |
| S06 | 83 tệp báo cáo API còn lưu, có hash và trạng thái nguồn. | evidence/api-suite-history/saved-api-artifacts.json |
| S07 | Docker tái hiện 17/11; không thay report gốc. | evidence/historical-replay/index.html |

