# Issue #66: [Bug API] EAM-1318: Sai phân quyền, giáo viên xóa được thành viên khỏi lớp (Expect 403, Got 200)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/66

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
