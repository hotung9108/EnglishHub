# Issue #63: [Bug API] EAM-1306: Sai phân quyền, học viên ngoài lớp vẫn xem được danh sách thành viên (Expect 403, Got 200)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/63

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
