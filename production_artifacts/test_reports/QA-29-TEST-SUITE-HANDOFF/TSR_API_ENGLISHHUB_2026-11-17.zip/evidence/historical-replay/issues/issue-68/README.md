# Issue #68: [Bug API] EAM-1284: Thiếu validate độ dài tên lớp, cho phép tạo lớp 151 ký tự (Expect 400, Got 201)

Chưa tái hiện. Đã kiểm tra tên đúng 150 ký tự được tạo (201), 151 ký tự bị từ chối (400), với ngày hợp lệ. Chưa tái hiện lỗi cũ.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/68

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
