# Issue #115: # [BE19][Staging] Grading thiếu maxScoreSnapshot khiến giáo viên không lưu được điểm hợp lệ

Tái hiện triệu chứng lỗi lịch sử. Lưu điểm 6 trong module tối đa 10 trả 400. Tái hiện triệu chứng; không suy diễn maxScoreSnapshot trong DB từ DTO không chứa trường này.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/115

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
