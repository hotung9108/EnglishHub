# Issue #65: [Bug API] EAM-1316: Xóa thành viên không thuộc lớp trả về 200 thay vì 404 (Expect 404, Got 200)

Chưa tái hiện. Tạo thành viên thật trong lớp nguồn, gọi xóa bằng ID lớp khác: trả 404 đúng kỳ vọng. Chưa tái hiện lỗi cũ; chưa đủ dữ liệu kết luận issue cũ là lỗi ảo.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/65

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
