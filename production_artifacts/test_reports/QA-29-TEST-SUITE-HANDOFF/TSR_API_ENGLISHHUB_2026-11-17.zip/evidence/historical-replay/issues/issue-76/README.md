# Issue #76: Endpoint GET /assignments/{id} (và có thể PUT /assignments/{id} — response của chính request update) không trả field maxSubmissions trong JSON, dù cột max_submissions trong DB có giá trị đúng.

Tái hiện triệu chứng lỗi lịch sử. Lỗi thật ở dữ liệu phản hồi: GET thiếu maxSubmissions dù PostgreSQL lưu đúng 3. Commit cũ 75 PASS/1 FAIL; commit sửa 76 PASS/0 FAIL. Không phải lỗi lưu DB.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/76

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
