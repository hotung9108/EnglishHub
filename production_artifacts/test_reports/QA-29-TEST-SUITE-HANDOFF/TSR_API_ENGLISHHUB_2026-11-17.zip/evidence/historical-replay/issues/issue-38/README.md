# Issue #38: [API USER] Lỗi 500 Internal Server Error khi gọi `PUT /api/v1/admin/users/{id}` (EAM-688)

Chưa tái hiện. Đã thử hai commit ứng viên, admin cập nhật trả 200. Chưa tái hiện lỗi 500 cũ.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/38

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
