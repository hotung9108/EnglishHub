# Issue #21: [API Auth] Endpoint /api/v1/auth/logout chấp nhận Access Token đã hết hạn (Trả về 200 OK thay vì 401)

Kỳ vọng đã bị phản bác. Kỳ vọng trong issue đã bị phản bác trong thảo luận nghiệp vụ. Không dùng FAIL lịch sử này làm lỗi sản phẩm đã xác nhận.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/21

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
