# Issue #37: [API USER] Lỗi 500 Internal Server Error khi đổi mật khẩu (UAPI-12)

Chưa tái hiện. Đã thử hai commit ứng viên, đổi mật khẩu trả 200. Chưa tái hiện lỗi 500 cũ.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/37

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
