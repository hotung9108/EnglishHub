# Issue #62: [API CLASSE]: EAM-1303 - Sai HTTP Status Code khi giáo viên xóa lớp (Expect 403, Get 409)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/62

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
