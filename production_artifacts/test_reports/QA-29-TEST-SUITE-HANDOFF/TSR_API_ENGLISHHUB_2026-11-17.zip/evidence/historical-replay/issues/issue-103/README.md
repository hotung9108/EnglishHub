# Issue #103: [Auth] POST /auth/logout trả 500 khi sử dụng refresh token hợp lệ

Tái hiện triệu chứng lỗi lịch sử. Logout bằng token mới hợp lệ trả 500. Có liên hệ nguyên nhân với #132 theo thảo luận cũ; không cộng thành hai nguyên nhân độc lập.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/103

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
