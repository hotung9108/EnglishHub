# Issue #69: [Bug API] EAM-1287: Sai phân quyền, giáo viên tạo được lớp học (Expect 403, Got 201)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/69

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
