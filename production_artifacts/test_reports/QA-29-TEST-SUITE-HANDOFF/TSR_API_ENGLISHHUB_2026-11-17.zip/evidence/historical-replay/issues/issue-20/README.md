# Issue #20: [API Auth] Trả về mã lỗi 500 thay vì 415 khi gửi thiếu/sai header Content-Type

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/20

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
