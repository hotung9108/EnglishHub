# Issue #132: [QA-19][Auth][Staging] Refresh token vừa login trả HTTP 500 khi chưa logout

Tái hiện triệu chứng lỗi lịch sử. Refresh bằng token mới hợp lệ trả 500. Có liên hệ với #103; không khẳng định là hai lỗi gốc độc lập.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/132

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
