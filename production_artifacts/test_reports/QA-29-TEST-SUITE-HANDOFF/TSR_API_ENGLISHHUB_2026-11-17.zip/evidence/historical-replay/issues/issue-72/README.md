# Issue #72: [Bug API] EAM-1297: Sai phân quyền, giáo viên cập nhật được thông tin lớp học (Expect 403, Got 200)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/72

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
