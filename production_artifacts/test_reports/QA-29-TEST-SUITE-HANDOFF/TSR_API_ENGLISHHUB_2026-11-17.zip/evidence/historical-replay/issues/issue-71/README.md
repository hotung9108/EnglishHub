# Issue #71: [Bug API] EAM-1286: Thiếu validate tên lớp trùng lặp, cho phép tạo lớp mới (Expect 400, Got 201)

Chưa xác nhận quy tắc. Tên lớp trùng: test ghi rõ quy tắc cần xác nhận. Có tái hiện HTTP 201, nhưng chưa đủ căn cứ gọi là lỗi yêu cầu.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/71

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
