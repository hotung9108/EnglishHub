# Issue #67: [Bug API] EAM-1278: Sai phân quyền, học viên ngoài lớp xem được chi tiết lớp (Expect 403/404, Got 200)

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/67

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
