# Issue #102: [BE20] Giáo viên không phụ trách lớp vẫn đọc được danh sách và chi tiết đánh giá học viên

Tái hiện triệu chứng lỗi lịch sử. Triệu chứng và HTTP khớp mô tả issue cũ trên commit ứng viên.

Nguồn: https://github.com/hotung9108/EnglishHub/issues/102

Xem report.html để đọc từng bước, request/response và commit; evidence.json chứa dữ liệu chi tiết.
