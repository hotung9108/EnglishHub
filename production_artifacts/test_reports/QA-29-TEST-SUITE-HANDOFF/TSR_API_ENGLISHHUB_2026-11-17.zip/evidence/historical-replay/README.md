# Bằng chứng lỗi API lịch sử — 17/11/2026

Đã khôi phục 19 ca FAIL lịch sử gắn 18 issue; tải 26 tệp đính kèm gốc và dựng 7 image Docker từ commit cũ. Đây là báo cáo chạy lại ngày 17/11/2026, không thay thế báo cáo gốc.

12/19 ca tái hiện triệu chứng lỗi (11 issue); 5 ca chưa tái hiện; 1 ca bị phản bác kỳ vọng (#21); 1 ca chưa xác nhận quy tắc (#71). Ngoài danh sách 19 ca, tái hiện thêm #103, #115, #132. Các con số không phải số nguyên nhân lỗi độc lập.

Mở index.html để đọc ma trận, các bước tái hiện, request/response và liên kết issue gốc.

Assignments cũ: 75 PASS/1 FAIL; sau sửa: 76 PASS/0 FAIL. Classes gốc 49 PASS/11 FAIL; chạy lại 50 PASS/10 FAIL. Không ép số liệu trùng khi thiếu DB và image triển khai gốc.

Các image/commit/hash: docker-builds.json. Nguồn 26 tệp đính kèm: original-attachments-manifest.json. Raw gốc và DB dump lưu riêng ngoài repo.
