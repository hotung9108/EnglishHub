# QA-20 - Truy vết phiên bản kiểm thử

Ngày truy vấn: 08/10/2026 (Asia/Saigon).
Nguồn: Git reflog HEAD tại BTL_PRJ1/EnglishHub, các CSV Qase trong tai lieu du an/, host API trong HTML Newman, log Qase và upload receipt.

## Mức xác nhận

Bảng dưới là commit local ứng viên: HEAD gần nhất trước thời điểm chạy, theo reflog. Đây chưa phải bằng chứng Docker image thực sự được build từ commit đó. Cần lưu ý image cũ, mã sửa chưa commit hoặc repository/worktree khác. Không dùng ngày commit để thay thời điểm pull.
Ngày chạy dưới đây lấy từ ngày của export; các log Newman dùng UTC. Khi so giờ pull dùng Asia/Saigon (+07:00).

| Nhóm | Ngày chạy trong export | Host/môi trường bằng chứng | Commit local ứng viên | Cơ sở và giới hạn |
| --- | --- | --- | --- | --- |
| Auth | 18/09/2026 | Tên Qase run ghi Staging; chưa xác minh host từ PDF | 36e05b47587dd5bd7e5b0e32dda7b0f539617dab | Pull develop 17/09 23:08:04, checkout staging 23:08:31; không xác nhận commit remote staging đã deploy |
| User | 21/09/2026 | Tên Qase run ghi Staging; chưa xác minh host từ PDF | cfc8d3f0d27bbb8c863b20d854cbfb2143a1a501 | Reset origin/staging 19/09 19:00:35; không xác nhận commit remote staging đã deploy |
| User Profile | 24/09/2026 | localhost:8080 trong HTML | c66ebe2f82e4a09d2d50bdede0b12186f07efb0a | Pull staging 24/09 20:08:52; export 14:49 UTC tương ứng 21:49 ICT. Chưa có image/build SHA |
| Classes | 26/09/2026 | localhost:8080 trong HTML | c66ebe2f82e4a09d2d50bdede0b12186f07efb0a | Qase/log chạy 14:37 UTC (21:37 ICT), trước pull 230a50b lúc 23:22:34. Không gán 230a50b cho lần chạy này |
| Assignments | 27/09/2026 | localhost:8080 trong HTML | 230a50b9be71165794c5020455e037761311cd16 | Pull staging 26/09 23:22:34, HEAD tiếp theo đổi 28/09 22:02:10. Log run 27/09 UTC |
| Submissions | 03/10/2026 | localhost:8080 trong HTML | f3e8758e45ec93e265e15e387ef312e68508cadc | Pull 01/10 07:35:51; worktree EnglishHub-be20-qase cũng có HEAD này từ 02/10. Chưa có image/build SHA |
| Student Evaluation | 05/10/2026 | localhost:8080 trong HTML | 0b08836fe89261e11a5b931588c24c6184f4bd88 | Checkout develop 19:53:43, pull 19:53:50, trước HTML 22:51 và Qase 23:00 ICT. Chưa xác minh hai export là cùng run |
| Grading | 07/10/2026 | api-staging.hotung9108.me trong HTML | Chưa xác minh commit deploy | Local HEAD lúc đó f3ce865f8b5c4ede025b7652165b9539caa3918c, nhưng không dùng làm build staging. Issue artifact cũng ghi chưa xác minh commit đang deploy |

## Run ID tìm được

- Assignments: Run 11 theo log testing/reports/newman/logs/log.txt tại 2026-09-27T16:26:11.769Z.
- Grading: EAM Run 18 theo receipt testing/reports/newman/report suite 15_20261007_220354.json.qase-upload.json. Đây là receipt local; CSV người dùng cung cấp là bằng chứng export kết quả.
- Các nhóm khác: chưa xác minh Run ID. Không nhầm biến runId dùng tạo fixture với ID test run Qase.

Chuỗi d2834134cd070dbcc08bf42ee27dabb746a1c54d xuất hiện giống nhau trong mọi HTML; không có nhãn chứng minh là application commit nên không sử dụng.

## Cách dùng trong TSR

Cột Build tested giữ Chưa xác minh nếu thiếu bằng chứng build/deploy. Đưa các commit trên vào cột Commit local tại thời điểm chạy (suy luận từ reflog), không ghi như build đã xác nhận. Có thể hoàn thiện TSR nháp mà không chạy test lại.
