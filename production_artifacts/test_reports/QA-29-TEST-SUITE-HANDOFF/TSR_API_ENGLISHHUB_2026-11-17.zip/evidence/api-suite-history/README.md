# Lịch sử kiểm thử API theo suite

Thu hồi ngày 17/11/2026; giữ kết quả và ngày chạy gốc. Đã tải 8 report suite đầu tiên và report hồi quy 10/10 từ Trello, không cần tạo lại số liệu bằng commit suy đoán.

| Suite | Chức năng | Ngày nguồn | Assessment | Report gốc |
|---|---|---|---|---|
| 8 | Auth | 2026-09-18 | {'Passed': 31, 'Failed': 2, 'Skipped': 1} | [Hồ sơ](suite-08-auth/2026-09-18-original/report.html) |
| 9 | User | 2026-09-21 | {'Passed': 28, 'Failed': 3, 'Blocked': 4} | [Hồ sơ](suite-09-users/2026-09-21-original/report.html) |
| 10 | User Profile | 2026-09-24 | {'Passed': 41} | [Hồ sơ](suite-10-profiles/2026-09-24-original/report.html) |
| 11 | Classes | 2026-09-26 | {'Failed': 11, 'Passed': 49} | [Hồ sơ](suite-11-classes/2026-09-26-original/report.html) |
| 12 | Assignments | 2026-09-27 | {'Passed': 75, 'Failed': 1} | [Hồ sơ](suite-12-assignments/2026-09-27-original/report.html) |
| 13 | Submissions | 2026-10-03 | {'Passed': 84} | [Hồ sơ](suite-13-submissions/2026-10-03-original/report.html) |
| 14 | Student Evaluation | 2026-10-05 | {'Passed': 71, 'Failed': 2} | [Hồ sơ](suite-14-evaluations/2026-10-05-original/report.html) |
| 15 | Grading | 2026-10-07 | {'Passed': 74, 'Blocked': 38, 'Skipped': 9} | [Hồ sơ](suite-15-grading/2026-10-07-original/report.html) |

## Phạm vi và giới hạn

- 8 bản nhị phân tải lại khớp hash nguồn TSR 08/10. 6 HTML Newman, 2 PDF kết quả Qase.
- 524 Assessment: 453 PASS, 19 FAIL, 42 BLOCKED, 10 SKIPPED. 31 Support đếm riêng.
- Report hồi quy 10/10: 560 dòng, 453 PASS / 7 FAIL / 88 BLOCKED / 12 SKIPPED; còn 4 ca cần đồng bộ Qase theo ghi chú nguồn.
- 83 tệp dữ liệu API đã lập danh mục; không coi mỗi tệp là một run.
- Commit của build gốc chưa được chứng minh; HEAD reflog chỉ là ứng viên. Không dùng probe riêng thay full suite hoặc ép số FAIL.
- Trạng thái issue hiện tại và retest về sau được giữ riêng, không sửa lịch sử.
- Mở index.html để tra cứu; mỗi suite/ngày có report.html, summary.json, cases.csv hoặc bảng case.
